# filter_portugal.py
import pandas as pd

# 1) load your full metadata
df = pd.read_parquet("metadata.parquet")

# 2) define Portugal bounds
min_lon, max_lon = -9.5, -6.0
min_lat, max_lat = 36.8,  42.1

# 3) filter
df_pt = df[
    df.longitude.between(min_lon, max_lon) &
    df.latitude .between(min_lat,  max_lat)
]

# 4) save
out_path = "metadata_portugal.parquet"
df_pt.to_parquet(out_path, index=False)
print(f"Portugal subset: {len(df_pt)} samples → wrote {out_path}")