# scripts/data_loader.py

from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
import rasterio
from rasterio.enums import Resampling

class BigEarthNetDataset(Dataset):
    """
    Two-level scan + per-band resampling + multi-hot label encoding.
    Skips any patch folders with zero .tif files.
    """
    def __init__(self, data_root: str, metadata_path: str, transform=None):
        self.data_root = Path(data_root)
        df = pd.read_parquet(metadata_path)

        # 1) Build raw patch_id -> folder map
        raw_id2dir = {}
        for tile in self.data_root.iterdir():
            if not tile.is_dir(): 
                continue
            for patch in tile.iterdir():
                if patch.is_dir():
                    raw_id2dir[patch.name] = patch

        # 2) Keep only those patch_ids present in metadata AND with at least 1 .tif
        valid_id2dir = {
            pid: pdir
            for pid, pdir in raw_id2dir.items()
            if pid in set(df["patch_id"]) and any(pdir.glob("*.tif"))
        }

        # 3) Filter metadata to these valid patch_ids
        df = df[df["patch_id"].isin(valid_id2dir)]
        self.patch_ids = df["patch_id"].tolist()
        raw_labels     = df["labels"].tolist()

        # 4) Build class list & index map
        unique_classes = sorted({c for lbls in raw_labels for c in lbls})
        self.classes      = unique_classes
        self.class_to_idx = {c:i for i,c in enumerate(unique_classes)}
        self.num_labels   = len(unique_classes)

        # 5) Precompute multi-hot label vectors
        self.labels = []
        for lbls in raw_labels:
            vec = np.zeros(self.num_labels, dtype=np.float32)
            for c in lbls:
                vec[self.class_to_idx[c]] = 1.0
            self.labels.append(vec)

        self.id2dir    = valid_id2dir
        self.transform = transform

    def __len__(self):
        return len(self.patch_ids)

    def __getitem__(self, idx):
        pid       = self.patch_ids[idx]
        patch_dir = self.id2dir[pid]

        # Read + resample all bands
        bands = []
        target_shape = None
        for tif in sorted(patch_dir.glob("*.tif")):
            with rasterio.open(tif) as src:
                if target_shape is None:
                    arr = src.read(1).astype(np.float32)
                    target_shape = arr.shape
                else:
                    h, w = target_shape
                    if (src.height, src.width) != target_shape:
                        arr = src.read(
                            1,
                            out_shape=(h, w),
                            resampling=Resampling.bilinear
                        ).astype(np.float32)
                    else:
                        arr = src.read(1).astype(np.float32)
            bands.append(arr)

        # now bands guaranteed non-empty
        arr   = np.stack(bands, axis=0)
        feats = arr.mean(axis=(1,2)).astype(np.float32)
        label = self.labels[idx]

        # Convert to fresh tensors so collate_fn works
        feats_tensor = torch.tensor(feats, dtype=torch.float32)
        label_tensor = torch.tensor(label, dtype=torch.float32)

        if self.transform:
            feats_tensor = self.transform(feats_tensor)
            label_tensor = self.transform(label_tensor)

        return feats_tensor, label_tensor

def collate_fn(batch):
    feats  = torch.stack([b[0] for b in batch], dim=0)
    labels = torch.stack([b[1] for b in batch], dim=0)
    return feats, labels

def make_dataloader(data_root, metadata_path,
                    batch_size=32, shuffle=True, num_workers=4):
    ds = BigEarthNetDataset(data_root, metadata_path)
    return DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        collate_fn=collate_fn
    )