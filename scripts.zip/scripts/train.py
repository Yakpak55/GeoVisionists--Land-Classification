# scripts/train.py

import argparse
import torch
from torch.utils.data import DataLoader, Subset, random_split
import pytorch_lightning as pl

from scripts.data_loader import BigEarthNetDataset, collate_fn
from scripts.model import LSTMClassifier

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_root",   required=True)
    parser.add_argument("--metadata",    required=True)
    parser.add_argument("--subset_size", type=int, default=None)
    parser.add_argument("--batch_size",  type=int, default=32)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--max_epochs",  type=int, default=10)

    # ← LSTM hyperparameters
    parser.add_argument("--hidden_dim", type=int,   default=64,   help="LSTM hidden size")
    parser.add_argument("--num_layers", type=int,   default=2,    help="Number of LSTM layers")
    parser.add_argument("--dropout",    type=float, default=0.3,  help="Dropout probability")
    parser.add_argument("--lr",         type=float, default=1e-3, help="Learning rate")

    args = parser.parse_args()

    # 1) load full dataset
    full_ds = BigEarthNetDataset(
        data_root=args.data_root,
        metadata_path=args.metadata
    )
    total = len(full_ds)
    print(f"Total samples in metadata: {total}")

    # 2) optional random subset
    if args.subset_size and args.subset_size < total:
        print(f"Using a random subset of {args.subset_size} samples")
        indices = torch.randperm(total)[: args.subset_size]
        ds = Subset(full_ds, indices)
    else:
        ds = full_ds

    # 3) train/val split
    n_val   = int(0.1 * len(ds))
    n_train = len(ds) - n_val
    train_ds, val_ds = random_split(ds, [n_train, n_val])
    print(f"Train size: {n_train},  Val size: {n_val}")

    # 4) DataLoaders
    pin_mem = torch.cuda.is_available()
    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=pin_mem,
        collate_fn=collate_fn
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=pin_mem,
        collate_fn=collate_fn
    )

    # 5) infer input_dim & num_classes
    batch_feats, _ = next(iter(train_loader))
    # if it's [B, F] add a fake time-dim of 1 to satisfy LSTM(batch, seq, feat)
    if batch_feats.ndim == 2:
        batch_feats = batch_feats.unsqueeze(1)
    input_dim   = batch_feats.shape[-1]
    num_classes = full_ds.num_labels

    # 6) build model
    model = LSTMClassifier(
        input_dim=input_dim,
        hidden_dim=args.hidden_dim,
        num_layers=args.num_layers,
        num_classes=num_classes,
        dropout=args.dropout,
        lr=args.lr,
    )

    # 7) trainer & fit
    trainer = pl.Trainer(
        max_epochs=args.max_epochs,
        accelerator="auto",
        devices=1,
        precision="16-mixed",
    )
    trainer.fit(model, train_loader, val_loader)


if __name__ == "__main__":
    main()
