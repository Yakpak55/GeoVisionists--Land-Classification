# scripts/evaluate.py

import glob
import torch
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from torch.utils.data import DataLoader
from data_loader import BigEarthNetDataset
from model import LSTMClassifier

def main():
    # 1) find the newest .ckpt in checkpoints/
    ckpt_paths = sorted(glob.glob("checkpoints/*.ckpt"))
    if not ckpt_paths:
        raise FileNotFoundError("No checkpoints found in ./checkpoints/")
    ckpt = ckpt_paths[-1]
    print(f"Loading checkpoint: {ckpt}")

    # 2) load model
    model = LSTMClassifier.load_from_checkpoint(ckpt)
    model.eval()

    # 3) prepare test loader
    ds = BigEarthNetDataset("BigEarthNet-S2/BigEarthNet-S2", "metadata.parquet")
    # —if you have a separate test split, swap in your test metadata/indices here
    loader = DataLoader(ds, batch_size=64, shuffle=False, num_workers=4, pin_memory=torch.cuda.is_available())

    # 4) run inference
    all_logits = []
    all_labels = []
    with torch.no_grad():
        for feats, labels in loader:
            # feats: [B, bands], LSTM expects [B, 1, bands]
            logits = model(feats.unsqueeze(1)).cpu().numpy()
            all_logits.append(logits)
            all_labels.append(labels.numpy())

    logits = np.vstack(all_logits)
    labels = np.vstack(all_labels)

    # 5) compute multi-label metrics
    mAP = average_precision_score(labels, logits, average="macro")
    AUC = roc_auc_score(labels, logits, average="macro")
    print(f"Test mAP: {mAP:.4f}")
    print(f"Test AUC: {AUC:.4f}")

if __name__ == "__main__":
    main()