# scripts/data_loader.py

from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
import rasterio
from rasterio.enums import Resampling

class BigEarthNetDataset(Dataset):
    """
    Scans two directory levels, builds a patch->TIFF-list,
    filters out any patch without TIFFs, and precomputes labels.
    """
    def __init__(self, data_root: str, metadata_path: str, transform=None):
        self.transform = transform

        # 1) Load metadata
        df = pd.read_parquet(metadata_path)

        # 2) Scan for patches and collect their TIFF paths
        base = Path(data_root)
        id2tifs = {}
        for tile in base.iterdir():
            if not tile.is_dir():
                continue
            for patch in tile.iterdir():
                if not patch.is_dir():
                    continue
                tifs = sorted(patch.glob("*.tif"))
                if tifs:
                    id2tifs[patch.name] = tifs

        # 3) Filter metadata to only those patch_ids we found TIFFs for
        df = df[df["patch_id"].isin(id2tifs.keys())].reset_index(drop=True)
        self.patch_ids = df["patch_id"].tolist()

        # 4) Build class list & index
        raw_lbls = df["labels"].tolist()
        classes = sorted({c for lbls in raw_lbls for c in lbls})
        self.classes      = classes
        self.class_to_idx = {c:i for i,c in enumerate(classes)}
        self.num_labels   = len(classes)

        # 5) Precompute multi-hot vectors
        self.labels = []
        for lbls in raw_lbls:
            vec = np.zeros(self.num_labels, dtype=np.float32)
            for c in lbls:
                vec[self.class_to_idx[c]] = 1.0
            self.labels.append(vec)

        # 6) Store the TIFF paths mapping
        self.id2tifs = id2tifs

    def __len__(self):
        return len(self.patch_ids)

    def __getitem__(self, idx):
        pid   = self.patch_ids[idx]
        tifs  = self.id2tifs[pid]   # guaranteed non-empty list

        # read & (if needed) resample each band to the first one's size
        bands = []
        target_shape = None
        for tif in tifs:
            with rasterio.open(tif) as src:
                arr = src.read(1).astype(np.float32)
                if target_shape is None:
                    target_shape = arr.shape
                elif (src.height, src.width) != target_shape:
                    arr = src.read(
                        1,
                        out_shape=target_shape,
                        resampling=Resampling.bilinear
                    ).astype(np.float32)
            bands.append(arr)

        # now safe to stack
        arr   = np.stack(bands, axis=0)             # (bands, H, W)
        feats = arr.mean(axis=(1,2)).astype(np.float32)
        lbl   = self.labels[idx]

        # FORCE new storage via torch.tensor()
        feats = torch.tensor(feats, dtype=torch.float32)
        lbl   = torch.tensor(lbl, dtype=torch.float32)

        if self.transform:
            feats = self.transform(feats)
            lbl   = self.transform(lbl)

        return feats, lbl

def collate_fn(batch):
    feats  = torch.stack([b[0] for b in batch], dim=0)
    labels = torch.stack([b[1] for b in batch], dim=0)
    return feats, labels

def make_dataloader(data_root, metadata_path,
                    batch_size=32, shuffle=True, num_workers=4):
    ds = BigEarthNetDataset(data_root, metadata_path)
    return DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        collate_fn=collate_fn
    )