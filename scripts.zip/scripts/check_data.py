# scripts/check_data.py
from pathlib import Path
import pandas as pd

# 1) Point at your data and metadata
BASE     = Path(r"C:\Users\Christopher Deluigi\OneDrive - University of Central Florida\Masters\Spring 2025\CAP 5610 - Machine Learning\Assignments\Semester Project")
DATA_DIR = BASE / "BigEarthNet-S2"
META     = BASE / "metadata.parquet"

# 2) Load metadata
df = pd.read_parquet(META)
print(f"Metadata rows: {len(df)}")

# 3) Count the patch files or folders
if any(p.suffix == ".npy" for p in DATA_DIR.iterdir()):
    total = sum(1 for p in DATA_DIR.iterdir() if p.suffix == ".npy")
    print(f"Found {total} .npy patch files")
else:
    total = sum(1 for p in DATA_DIR.iterdir() if p.is_dir())
    print(f"Found {total} patch subdirectories")

# 4) Print a quick sample
print("First 5 patch_ids:", df.patch_id.tolist()[:5])
print("First 5 data entries:", [p.name for p in list(DATA_DIR.iterdir())[:5]])